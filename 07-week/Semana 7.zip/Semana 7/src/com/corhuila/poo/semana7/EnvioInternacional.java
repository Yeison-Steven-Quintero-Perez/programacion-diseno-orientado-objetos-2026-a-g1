package com.corhuila.poo.semana7;

public class EnvioInternacional extends Envio {
    private static final double TARIFA_POR_KG = 10.0;
    private static final double IMPUESTO_PORCENTAJE = 0.20;

    public EnvioInternacional(String origen, String destino, double pesoKg) {
        super(origen, destino, pesoKg);
    }

    @Override
    public double calcularCosto() {
        double subtotal = getPesoKg() * TARIFA_POR_KG;
        return subtotal + subtotal * IMPUESTO_PORCENTAJE;
    }
}
