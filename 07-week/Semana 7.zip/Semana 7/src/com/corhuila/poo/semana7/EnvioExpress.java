package com.corhuila.poo.semana7;

public class EnvioExpress extends Envio {
    private static final double TARIFA_BASE = 15.0;
    private static final double TARIFA_POR_KG = 7.0;

    public EnvioExpress(String origen, String destino, double pesoKg) {
        super(origen, destino, pesoKg);
    }

    @Override
    public double calcularCosto() {
        return TARIFA_BASE + getPesoKg() * TARIFA_POR_KG;
    }
}
