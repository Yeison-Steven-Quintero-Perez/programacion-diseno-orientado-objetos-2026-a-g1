package com.corhuila.poo.semana7;

import java.util.ArrayList;
import java.util.List;

public class App {
    public static void main(String[] args) {
        List<Envio> envios = new ArrayList<>();

        envios.add(new EnvioEstandar("Bogotá", "Medellín", 4.2));
        envios.add(new EnvioExpress("Cali", "Barranquilla", 2.5));
        envios.add(new EnvioInternacional("Bogotá", "Miami", 3.0));
        envios.add(new EnvioEstandar("Pereira", "Manizales", 1.8));

        double total = 0.0;

        System.out.println("Detalle de envíos:");
        System.out.println("------------------");
        for (Envio envio : envios) {
            double costo = envio.calcularCosto();
            total += costo;
            System.out.printf("%s | Tipo: %s | Costo: $%.2f%n",
                    envio,
                    envio.getClass().getSimpleName(),
                    costo);
        }

        System.out.println("------------------");
        System.out.printf("Costo total de todos los envíos: $%.2f%n", total);
    }
}
