package com.corhuila.poo.semana7;

public abstract class Envio {
    private String origen;
    private String destino;
    private double pesoKg;

    public Envio(String origen, String destino, double pesoKg) {
        this.origen = origen;
        this.destino = destino;
        this.pesoKg = pesoKg;
    }

    public String getOrigen() {
        return origen;
    }

    public String getDestino() {
        return destino;
    }

    public double getPesoKg() {
        return pesoKg;
    }

    public abstract double calcularCosto();

    @Override
    public String toString() {
        return String.format("Envio desde %s hasta %s - peso: %.2f kg", origen, destino, pesoKg);
    }
}
