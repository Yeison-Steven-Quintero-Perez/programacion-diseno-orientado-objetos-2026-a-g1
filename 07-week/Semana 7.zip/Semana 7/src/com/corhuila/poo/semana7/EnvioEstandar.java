package com.corhuila.poo.semana7;

public class EnvioEstandar extends Envio {
    private static final double TARIFA_POR_KG = 5.0;

    public EnvioEstandar(String origen, String destino, double pesoKg) {
        super(origen, destino, pesoKg);
    }

    @Override
    public double calcularCosto() {
        return getPesoKg() * TARIFA_POR_KG;
    }
}
