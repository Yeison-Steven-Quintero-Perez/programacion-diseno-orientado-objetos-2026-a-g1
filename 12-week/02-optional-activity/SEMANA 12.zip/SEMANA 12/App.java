public class App {
    public static void main(String[] args) {
        Inventario inventario = new Inventario();

        // Agregar productos universitarios con código único.
        inventario.agregarProducto(new Producto("A001", "Lapicera gel negra 0.7 mm", 12.50));
        inventario.agregarProducto(new Producto("B002", "Cuaderno universitario A4 100 hojas", 45.00));
        inventario.agregarProducto(new Producto("C003", "Regla transparente 30 cm", 18.75));
        inventario.agregarProducto(new Producto("D004", "Mochila urbana 20L", 399.90));

        // Prueba de código duplicado.
        inventario.agregarProducto(new Producto("A001", "Lapicera gel azul 0.7 mm", 14.00));

        // Entradas de stock.
        inventario.entrada("A001", 50);
        inventario.entrada("B002", 30);
        inventario.entrada("C003", 100);
        inventario.entrada("D004", 10);

        // Salidas de stock válidas.
        inventario.salida("B002", 5);
        inventario.salida("C003", 15);
        inventario.salida("D004", 1);

        // Salida inválida por stock insuficiente.
        inventario.salida("A001", 60);

        // Busca un producto existente y otro que no está.
        buscarProducto(inventario, "B002");
        buscarProducto(inventario, "X999");

        // Imprime el inventario final.
        inventario.listar();
    }

    private static void buscarProducto(Inventario inventario, String codigo) {
        Producto producto = inventario.buscar(codigo);
        if (producto == null) {
            System.out.println("Producto no encontrado: " + codigo);
        } else {
            System.out.println("Producto encontrado: " + producto);
        }
    }
}
