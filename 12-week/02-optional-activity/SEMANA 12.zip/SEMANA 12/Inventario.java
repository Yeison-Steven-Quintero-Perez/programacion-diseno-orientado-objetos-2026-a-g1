import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class Inventario {
    private final Map<String, Producto> productos;
    private final Map<String, Integer> cantidades;

    public Inventario() {
        this.productos = new HashMap<>();
        this.cantidades = new HashMap<>();
    }

    public void agregarProducto(Producto producto) {
        String codigo = producto.getCodigo();
        if (productos.containsKey(codigo)) {
            System.out.println("Error: el código ya existe -> " + codigo);
            return;
        }
        productos.put(codigo, producto);
        cantidades.put(codigo, 0);
        System.out.println("Producto agregado: " + producto);
    }

    public void entrada(String codigo, int cantidad) {
        if (cantidad <= 0) {
            System.out.println("Error: la cantidad de entrada debe ser positiva.");
            return;
        }
        if (!productos.containsKey(codigo)) {
            System.out.println("Error: producto no existe -> " + codigo);
            return;
        }
        int actual = cantidades.getOrDefault(codigo, 0);
        cantidades.put(codigo, actual + cantidad);
        System.out.printf("Entrada registrada: %s +%d (nuevo stock %d)\n", codigo, cantidad, actual + cantidad);
    }

    public void salida(String codigo, int cantidad) {
        if (cantidad <= 0) {
            System.out.println("Error: la cantidad de salida debe ser positiva.");
            return;
        }
        if (!productos.containsKey(codigo)) {
            System.out.println("Error: producto no existe -> " + codigo);
            return;
        }
        int actual = cantidades.getOrDefault(codigo, 0);
        if (cantidad > actual) {
            System.out.printf("Error: stock insuficiente para %s. Disponible=%d, pedido=%d\n", codigo, actual, cantidad);
            return;
        }
        cantidades.put(codigo, actual - cantidad);
        System.out.printf("Salida registrada: %s -%d (nuevo stock %d)\n", codigo, cantidad, actual - cantidad);
    }

    public Producto buscar(String codigo) {
        return productos.get(codigo);
    }

    public void listar() {
        System.out.println("\n--- Inventario actual ---");
        Map<String, Producto> ordenado = new TreeMap<>(productos);
        for (Map.Entry<String, Producto> entry : ordenado.entrySet()) {
            String codigo = entry.getKey();
            Producto producto = entry.getValue();
            int stock = cantidades.getOrDefault(codigo, 0);
            System.out.printf("%s | %s | Stock=%d\n", codigo, producto.getNombre(), stock);
        }
    }
}
