# Registro de Productos

Este mini-sistema cumple los requisitos de la actividad y presenta una solución organizada y robusta.

- `Producto` valida `codigo`, `nombre` y `precio` con `IllegalArgumentException`.
- `ProductoDuplicadoException` es una excepción de negocio para evitar códigos repetidos.
- `Inventario` mantiene productos en un mapa por código y permite buscar, eliminar y listar.
- `App` muestra cómo agregar productos, buscar por código y eliminar con manejo de errores.

## Archivos
- `src/Producto.java`
- `src/ProductoDuplicadoException.java`
- `src/Inventario.java`
- `src/App.java`

## Ejecución
Desde `Entrega`:

```bash
javac src\*.java
java -cp src App
```

## Ejemplo de salida en consola

```text
=== Registro de productos ===
Producto agregado: A001 - Cuaderno
Producto agregado: A002 - Lapicero
Producto agregado: A003 - Regla
Regla comercial: Ya existe un producto con el código: A002
Validación fallida: Nombre inválido: no puede quedar vacío.
Validación fallida: Precio inválido: debe ser mayor que cero.

=== Estado del inventario ===
 - Producto[codigo=A001, nombre=Cuaderno, precio=2500,00]
 - Producto[codigo=A002, nombre=Lapicero, precio=350,00]
 - Producto[codigo=A003, nombre=Regla, precio=1200,00]

Buscar producto con código A003:
 -> Producto[codigo=A003, nombre=Regla, precio=1200,00]

Eliminar producto con código A003...
Producto A003 eliminado correctamente.

Productos finales en inventario:
 - Producto[codigo=A001, nombre=Cuaderno, precio=2500,00]
 - Producto[codigo=A002, nombre=Lapicero, precio=350,00]
```

## Explicación breve
1. Se validó con `IllegalArgumentException` que `codigo` y `nombre` no sean nulos o vacíos y que `precio` sea mayor que cero.
2. Se creó `ProductoDuplicadoException` para manejar la regla de negocio de códigos únicos.
3. `Inventario` usa un mapa para evitar duplicados, buscar por código y eliminar productos de forma eficiente.
4. `App` captura las excepciones y demuestra que el programa continúa funcionando sin detenerse.
