import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Inventario {
    private final Map<String, Producto> productosPorCodigo;

    public Inventario() {
        this.productosPorCodigo = new LinkedHashMap<>();
    }

    public void agregarProducto(Producto producto) {
        if (producto == null) {
            throw new IllegalArgumentException("El producto no puede ser nulo.");
        }

        String codigoNormalizado = normalizarCodigo(producto.getCodigo());
        if (productosPorCodigo.containsKey(codigoNormalizado)) {
            throw new ProductoDuplicadoException("Ya existe un producto con el código: " + producto.getCodigo());
        }

        productosPorCodigo.put(codigoNormalizado, producto);
    }

    public Producto buscarProductoPorCodigo(String codigo) {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código para buscar no puede ser nulo o vacío.");
        }
        return productosPorCodigo.get(normalizarCodigo(codigo));
    }

    public boolean contieneCodigo(String codigo) {
        if (codigo == null || codigo.trim().isEmpty()) {
            return false;
        }
        return productosPorCodigo.containsKey(normalizarCodigo(codigo));
    }

    public void eliminarProductoPorCodigo(String codigo) {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código para eliminar no puede ser nulo o vacío.");
        }

        String codigoNormalizado = normalizarCodigo(codigo);
        if (!productosPorCodigo.containsKey(codigoNormalizado)) {
            throw new IllegalArgumentException("No existe un producto con el código: " + codigo);
        }

        productosPorCodigo.remove(codigoNormalizado);
    }

    public List<Producto> getProductos() {
        return Collections.unmodifiableList(new ArrayList<>(productosPorCodigo.values()));
    }

    private String normalizarCodigo(String codigo) {
        return codigo.trim().toUpperCase();
    }
}
