public class App {
    public static void main(String[] args) {
        Inventario inventario = new Inventario();

        System.out.println("=== Registro de productos ===");
        agregarConValidacion(inventario, "A001", "Cuaderno", 2500.0);
        agregarConValidacion(inventario, "A002", "Lapicero", 350.0);
        agregarConValidacion(inventario, "A003", "Regla", 1200.0);
        agregarConValidacion(inventario, "A002", "Bolígrafo", 450.0); // duplicado
        agregarConValidacion(inventario, "A004", "", 1800.0); // nombre inválido
        agregarConValidacion(inventario, "A005", "Tijeras", -50.0); // precio inválido

        System.out.println();
        System.out.println("=== Estado del inventario ===");
        inventario.getProductos().forEach(producto -> System.out.println(" - " + producto));

        System.out.println();
        String codigoBuscado = "A003";
        System.out.println("Buscar producto con código " + codigoBuscado + ":");
        Producto encontrado = inventario.buscarProductoPorCodigo(codigoBuscado);
        System.out.println(encontrado != null ? " -> " + encontrado : " -> No encontrado");

        System.out.println();
        System.out.println("Eliminar producto con código A003...");
        try {
            inventario.eliminarProductoPorCodigo("A003");
            System.out.println("Producto A003 eliminado correctamente.");
        } catch (IllegalArgumentException e) {
            System.out.println("No se pudo eliminar: " + e.getMessage());
        }

        System.out.println();
        System.out.println("Productos finales en inventario:");
        inventario.getProductos().forEach(producto -> System.out.println(" - " + producto));
    }

    private static void agregarConValidacion(Inventario inventario, String codigo, String nombre, double precio) {
        try {
            Producto producto = new Producto(codigo, nombre, precio);
            inventario.agregarProducto(producto);
            System.out.println("Producto agregado: " + producto.getCodigo() + " - " + producto.getNombre());
        } catch (IllegalArgumentException e) {
            System.out.println("Validación fallida: " + e.getMessage());
        } catch (ProductoDuplicadoException e) {
            System.out.println("Regla comercial: " + e.getMessage());
        }
    }
}
