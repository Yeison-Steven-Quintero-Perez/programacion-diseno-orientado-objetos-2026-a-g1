package com.corhuila.poo.semana6;

public class Administrativo extends Persona {
    private String cargo;

    public Administrativo(String nombre, int edad, String documento, String cargo) {
        super(nombre, edad, documento); // 🔥 herencia
        this.cargo = cargo;
    }

    public void mostrarInfo() {
        super.mostrarInfo();
        System.out.println("Cargo: " + cargo);
    }
}