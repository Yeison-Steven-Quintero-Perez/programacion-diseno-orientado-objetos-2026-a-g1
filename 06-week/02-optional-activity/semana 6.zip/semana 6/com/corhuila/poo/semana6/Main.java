package com.corhuila.poo.semana6;

public class Main {
    public static void main(String[] args) {

        Docente d1 = new Docente("Carlos Perez", 40, "12345", "Matemáticas");
        Administrativo a1 = new Administrativo("Laura Gomez", 35, "67890", "Secretaria");

        System.out.println("=== DOCENTE ===");
        d1.mostrarInfo();

        System.out.println("\n=== ADMINISTRATIVO ===");
        a1.mostrarInfo();
    }
}