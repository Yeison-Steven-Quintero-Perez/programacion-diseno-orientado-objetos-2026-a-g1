package com.corhuila.poo.semana6;

public class Docente extends Persona {
    private String materia;

    public Docente(String nombre, int edad, String documento, String materia) {
        super(nombre, edad, documento); // 🔥 herencia
        this.materia = materia;
    }

    public void mostrarInfo() {
        super.mostrarInfo();
        System.out.println("Materia: " + materia);
    }
}