# Explicación del Sistema de Persistencia de Productos

## Rutas Relativas
Se utilizó `data/productos.csv` en lugar de rutas absolutas (`C:\ruta\completa...`). Esto permite que el código sea portátil: funciona en cualquier máquina sin modificar la ruta, siempre que se respete la estructura de carpetas relativa al directorio del proyecto.

## Separación Modelo y Persistencia
La arquitectura separa responsabilidades en tres clases independientes:
- **Producto**: Modelo de datos con atributos `final` (inmutable) y método `toString()` que genera el formato CSV (codigo,nombre,precio).
- **ArchivoProductos**: Clase de persistencia con métodos estáticos `cargar()` para leer el CSV y `guardar()` para escribir. No depende de la lógica de negocio.
- **App**: Orquestadora que carga, modifica y persiste datos. Utiliza ambas clases sin acoplamiento.

## Manejo de Archivo Inexistente
Si el archivo no existe, `cargar()` verifica con `Files.exists()` y crea automáticamente la carpeta `data/` con `Files.createDirectories()`, retornando lista vacía sin excepciones. En `guardar()` se utiliza `TRUNCATE_EXISTING` para sobrescribir el archivo de forma consistente, garantizando sincronización entre memoria y disco.

