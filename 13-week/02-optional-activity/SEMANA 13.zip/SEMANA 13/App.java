import java.util.List;

public class App {
    public static void main(String[] args) {
        List<Producto> productos = ArchivoProductos.cargar();
        
        if (productos.isEmpty()) {
            productos.add(new Producto("P001", "Laptop", 999.99));
            productos.add(new Producto("P002", "Mouse", 29.99));
            productos.add(new Producto("P003", "Teclado", 79.99));
        } else {
            System.out.println("Productos cargados:");
            for (Producto p : productos) {
                System.out.println(p.getNombre() + " - $" + p.getPrecio());
            }
        }

        productos.add(new Producto("P004", "Monitor", 199.99));

        ArchivoProductos.guardar(productos);

        System.out.println("\nProductos guardados:");
        for (Producto p : productos) {
            System.out.println(p.getNombre() + " - $" + p.getPrecio());
        }
    }
}

