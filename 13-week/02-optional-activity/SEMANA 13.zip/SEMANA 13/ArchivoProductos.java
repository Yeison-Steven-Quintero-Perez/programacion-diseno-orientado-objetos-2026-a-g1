import java.io.*;
import java.nio.file.*;
import java.util.*;

public class ArchivoProductos {
    private static final String RUTA = "data/productos.csv";

    public static List<Producto> cargar() {
        List<Producto> productos = new ArrayList<>();
        Path ruta = Paths.get(RUTA);

        try {
            if (!Files.exists(ruta)) {
                Files.createDirectories(ruta.getParent());
                return productos;
            }

            List<String> lineas = Files.readAllLines(ruta);
            for (String linea : lineas) {
                if (!linea.trim().isEmpty()) {
                    String[] partes = linea.split(",");
                    if (partes.length == 3) {
                        String codigo = partes[0];
                        String nombre = partes[1];
                        double precio = Double.parseDouble(partes[2]);
                        productos.add(new Producto(codigo, nombre, precio));
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error al cargar archivo: " + e.getMessage());
        }

        return productos;
    }

    public static void guardar(List<Producto> productos) {
        Path ruta = Paths.get(RUTA);

        try {
            Files.createDirectories(ruta.getParent());
            try (BufferedWriter writer = Files.newBufferedWriter(ruta,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING)) {
                for (Producto p : productos) {
                    writer.write(p.toString());
                    writer.newLine();
                }
            }
        } catch (IOException e) {
            System.out.println("Error al guardar archivo: " + e.getMessage());
        }
    }
}
