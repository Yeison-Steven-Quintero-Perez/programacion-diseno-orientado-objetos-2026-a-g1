package app;
import model.TipoCliente;
import service.FacturacionService;

public class AppRefactor {
    public static void main(String[] args) {
        // Técnica: Rename (Nombres claros y descriptivos)
        double subtotal = 500000;
        boolean aplicaIva = true;
        boolean aplicaDescuento = true;
        
        // Reemplazo de (int t = 1) por un Enum fuerte
        TipoCliente tipoCliente = TipoCliente.VIP; 

        // Instanciamos el servicio y calculamos
        FacturacionService servicio = new FacturacionService();
        double total = servicio.calcularTotalFinal(subtotal, aplicaDescuento, aplicaIva, tipoCliente);

        System.out.println("Total: " + total);
    }
}