package service;

import model.TipoCliente;

public class FacturacionService {

    // Técnica: Introduce Constant (Eliminación de números mágicos)
    private static final double TASA_IVA = 0.19;
    private static final double DESCUENTO_VIP = 0.20;
    private static final double DESCUENTO_FRECUENTE = 0.10;
    private static final double DESCUENTO_NORMAL = 0.05;

    // Técnica: Extract Method (Método principal orquestador)
    public double calcularTotalFinal(double subtotal, boolean aplicaDescuento, boolean aplicaIva, TipoCliente tipoCliente) {
        if (subtotal <= 0) {
            return 0.0;
        }

        double total = subtotal;

        if (aplicaDescuento) {
            total = aplicarDescuento(total, tipoCliente);
        }

        if (aplicaIva) {
            total = aplicarIva(total);
        }

        return redondear(total);
    }

    // Técnica: Extract Method (Lógica de descuento aislada)
    private double aplicarDescuento(double monto, TipoCliente tipoCliente) {
        double porcentajeDescuento = switch (tipoCliente) {
            case VIP -> DESCUENTO_VIP;
            case FRECUENTE -> DESCUENTO_FRECUENTE;
            case NORMAL -> DESCUENTO_NORMAL;
        };
        return monto - (monto * porcentajeDescuento);
    }

    // Técnica: Extract Method (Lógica de impuestos aislada)
    private double aplicarIva(double monto) {
        return monto + (monto * TASA_IVA);
    }

    private double redondear(double monto) {
        return Math.round(monto * 100.0) / 100.0;
    }
}